# @tossdown/orders-sdk

Framework-neutral Order SDK for cart orchestration and mounting the Tossdown
Checkout MFE inside any host app. It can be used from React, Next.js, Vue,
Svelte, vanilla JavaScript, or another framework.

The recommended integration is `createOrderSdk`. The host renders its menu and
buttons, but the SDK owns cart state, persistence, local validation, fulfilment
validation, cart mutations, order submission, payment handoff, and loading the
Checkout MFE. The MFE is the checkout presentation layer.

## Install

```bash
npm install @tossdown/orders-sdk
```

For a private registry, configure the `@tossdown` scope once in the consuming
project, then install the same package normally:

```bash
npm config set @tossdown:registry <private-registry-url>
npm login --registry <private-registry-url>
npm install @tossdown/orders-sdk
```

From the SDK project, run `npm run publish:private` after authentication. The
`prepublishOnly` gate runs typecheck, tests, and the production build first.

The package is a browser-side TypeScript/JavaScript library; it is not a Next.js
application. It may be imported by a Next.js app, but create the SDK in a
client-only component or event handler because it uses browser APIs.

The package is configured for restricted publication (`publishConfig.access` is
`restricted`). Publish it to the organization’s private npm registry, then pin
that version in each host and MFE; the SDK package does not require a public npm
release to run.

## What the host supplies and what the SDK owns

| Host app supplies | Order SDK owns |
| --- | --- |
| Menu/product UI and the selected product | Cart creation, persistence, and synchronization |
| Product modifier metadata when adding an item | Required/optional modifier validation |
| Storefront identity, catalog data, locations, and delivery zones | API origin, endpoint mapping, add/update/remove/clear, and debounced quantity operations |
| The current fulfilment selection and customer context | Delivery-area/range and location/order-type validation |
| Navigation URLs, theme, and optional public map/payment settings | Checkout MFE script/style loading and SDK-to-MFE cart bridge |
| A short-lived auth token, if the host owns sign-in | Order submission, payment handoff, lifecycle events, and cleanup |

The host should not maintain a second cart implementation or append the Checkout
MFE `<script>`/`<link>` itself.

For a host that also needs standard storefront discovery, use the SDK transport
instead of duplicating Ordrz requests:

```ts
import { createHttpStorefrontTransport } from "@tossdown/orders-sdk";

const storefront = createHttpStorefrontTransport();
const storefrontResponse = await storefront.getByUsername("my-store");
// Resolve the business ID from the public storefront response, then load:
const locationsResponse = await storefront.getLocations(businessId);
const productsResponse = await storefront.getProducts(businessId, {
  page: 1,
  pageSize: 48,
  include: "modifiers",
});
```

The transport defaults to `https://apiv2.ordrz.com/api/v1`; pass `apiBaseUrl`
only when intentionally targeting a compatible private API or BFF.

Checkout address search and reverse-geocoding can also be routed through the
SDK without exposing provider details to the MFE. Supply a provider-specific
adapter when the host has a server proxy or approved geocoder:

```ts
const order = createOrderSdk({
  businessId: "business-id",
  geocoder: {
    search: (query, options) => addressProxy.search(query, options),
    reverse: (latitude, longitude, options) =>
      addressProxy.reverse(latitude, longitude, options),
  },
});
```

The SDK intentionally does not select or call a third-party geocoder by
default; this keeps address/coordinate data within the host’s approved privacy
boundary.

## Complete ordering integration (recommended)

This example is framework-neutral. A React/Next host can call the same methods
from event handlers and render `#checkout-root` in a client component.

For the standard Ordrz backend, `apiBaseUrl` and `storefront` are optional: the
SDK defaults to `https://apiv2.ordrz.com/api/v1` and derives the storefront key
from `businessId`. A host can still explicitly point the SDK at its own BFF.

```ts
const order = createOrderSdk({ businessId: "business-id", currency: "PKR" });
await order.initialize();
await order.setFulfilment({ orderType: "PICKUP", locationId: "branch-1", scheduledAt: "ASAP" });
await order.addItem({ productId: "item-1", quantity: 1 });
const context = order.getCheckoutContext();
```

Provide `locations`, `products`, and an explicit `mfeUrl` when the host needs
local fulfilment/modifier validation or is loading a deployed Checkout MFE.

```ts
import { createOrderSdk } from "@tossdown/orders-sdk";

const order = createOrderSdk({
  // Use a pinned HTTPS release in production. In local development the SDK can
  // resolve the Nova dev bundle when mfeUrl is omitted.
  mfeUrl: "https://checkout-cdn.example/v1/index.global.js",
  stylesheetUrl: "https://checkout-cdn.example/v1/index.global.css",
  businessId: "business-id",
  storefront: "my-store",
  apiBaseUrl: "https://merchant.example",
  currency: "PKR",
  locations: [
    {
      id: "paf-cinema",
      name: "PAF Cinema Bus Stop",
      supportedOrderTypes: ["PICKUP", "DELIVERY"],
      active: true,
      acceptingOrders: true,
      deliveryZones: [
        { id: "model-town", name: "Model Town", radiusKm: 8 },
      ],
    },
  ],
  // Optional: restore a cart created by a previous host session.
  cartReference: window.localStorage.getItem("my-cart-id"),
  fulfilment: {
    orderType: "DELIVERY",
    locationId: "paf-cinema",
    deliveryZoneId: "model-town",
    scheduledAt: "ASAP",
    deliveryAddress: {
      label: "Work",
      latitude: 31.4801,
      longitude: 74.3224,
      addressLine1: "3k Model Town",
      city: "Lahore",
      country: "Pakistan",
    },
  },
});

await order.initialize();

// Call this from the host menu's Add button. The host passes the selected
// modifier metadata so the SDK can validate the same rules before transport.
await order.addItem({
  productId: product.id,
  quantity: 1,
  modifiers: selectedOptions.map((option) => ({
    groupId: option.groupId,
    optionId: option.id,
    quantity: option.quantity,
  })),
  modifierGroups: product.modifierGroups,
  instructions: "No onions",
});

const cartId = order.getState()?.cart?.id;
if (!cartId) throw new Error("Add an item or provide cartReference before checkout.");

const checkout = await order.mountCheckout(document.querySelector("#checkout-root")!, {
  source: "my-host-app",
  navigation: { continueShoppingUrl: "/menu", homeUrl: "/" },
  theme: { primaryColor: "#d71936", pageBackground: "#000000", pageText: "#ffffff" },
  hostShell: true,
}, {
  onReady: ({ cartId }) => console.log("Checkout ready", cartId),
  onOrderComplete: ({ orderId }) => console.log("Order placed", orderId),
  onExit: ({ reason }) => {
    if (reason === "back_to_shop") order.clearLocalAfterOrder();
  },
  onError: (error) => console.error("Checkout error", error),
});

checkout.unmount();
order.destroy();

// The SDK fills businessId, cartReference, fulfilment, API origin, locale,
// currency and the remaining required checkout fields from its current state.
// A complete CheckoutRuntimeConfig is still accepted when a host needs full
// control over every field.
```


For a fresh cart, call `addItem` before mounting. The standard transport creates
the cart on the first add and returns its ID in the `X-Cart-Id` response header;
the SDK persists that ID for the configured `storefront`. A host may instead
pass an existing opaque `cartReference`.

## Complete account integration

The same SDK instance can mount the Profile MFE. It owns the customer session,
login/signup OTP requests, profile loading, order history, and sign-out while
the MFE renders the account UI inside the host-provided shell.

```ts
const profile = await order.mountProfile(
  document.querySelector("#profile-root")!,
  {
    source: "my-host-app",
    businessName: "My Store",
    navigation: { homeUrl: "/" },
    hostShell: true,
  },
  {
    onReady: ({ businessId }) => console.log("Profile ready", businessId),
    onError: (error) => console.error("Profile error", error),
  },
);

// When the host route/component is removed:
profile.unmount();
order.destroy();
```

With the built-in transport, no separate Profile API client is required. For a
non-standard backend, provide `profileAdapter` to `createOrderSdk`; the host
still calls `order.mountProfile` and does not reimplement auth or account data
loading.

## Required host data

`createOrderSdk` needs:

- `businessId`. The SDK derives a stable storefront key from it unless the host
  supplies an explicit `storefront`.
- `apiBaseUrl` only when overriding the canonical Ordrz base or using a custom
  BFF; custom `cartAdapter`/`orderAdapter` remain available for non-standard APIs.
- `currency` for the built-in transport (otherwise it defaults to `USD`).
- `locations` with supported order types when the host wants immediate local
  branch/zone validation. If omitted, the SDK still validates the required
  fulfilment shape and the API remains authoritative for branch availability,
  order types, and delivery fences. Include delivery zones when using local
  area/radius/polygon delivery validation.
- With the built-in standard transport, omitted `locations` are loaded from
  the SDK-owned locations endpoint during `initialize()`. Pass `locations`
  explicitly only when the host already has fresher server-authoritative
  storefront data or wants to avoid that bootstrap request.
- A fulfilment context before adding a delivery item:
  `{ orderType: "DELIVERY", locationId, deliveryZoneId?, deliveryAddress?, scheduledAt }`.
  `scheduledAt` is `"ASAP"` or an ISO timestamp.
- Product modifier groups and selected options when calling `order.addItem`.
  Required groups use `required: true` or `minSelections > 0`; optional groups
  use `required: false` and `minSelections: 0`.
- Available schedule slots are optional host input (`scheduleSlots`). The SDK
  validates a scheduled timestamp against those slots, but never fetches the
  catalog, modifiers, or slots itself.

The checkout runtime uses the presentation form of fulfilment (`pickup`,
`delivery`, or `dine_in`, plus `scheduleMode`). When mounted through
`createOrderSdk`, the SDK injects the authoritative cart snapshot and
`orderRuntime`; the MFE must use that runtime for cart operations.

## Order SDK API

```ts
await order.initialize();
await order.setFulfilment({
  orderType: "PICKUP",
  locationId: "paf-cinema",
  scheduledAt: "ASAP",
});
order.clearFulfilment();

await order.addItem({ productId: "item-id", quantity: 1 });
await order.updateQuantity("line-id", 2); // debounced and synchronized
await order.updateItem("line-id", { quantity: 1, instructions: "Extra spicy" });
await order.removeItem("line-id");
await order.clearCart();
await order.calculate();

// The same SDK owns final order validation and placement.
await order.validateOrder({ customerDetails: { name: "Jane", email: "jane@example.com", phone: "+923001234567" } });
await order.placeOrder({ customerDetails: { name: "Jane", email: "jane@example.com", phone: "+923001234567" } });
// If paymentType is omitted, the SDK normalizes the Nova-compatible default:
// CASH_ON_DELIVERY. Explicit online payment types are preserved.

const unsubscribe = order.subscribe((state) => {
  // Render the host's cart badge from SDK state.
  console.log(state.cart?.items, state.cart?.total);
});
// Or pass onCartEvent to createOrderSdk for typed events.
unsubscribe();
// After a confirmed order, remove the persisted cart snapshot.
order.clearLocalAfterOrder();
```

The nested `order.cart` client is still available for advanced integrations
and backwards compatibility, but new hosts should use the top-level methods.

The SDK emits `cart:ready`, `cart:item-added`, `cart:item-removed`,
`cart:changed`, `fulfilment:changed`, `cart:expired`, and `cart:error` events.
Errors include modifier, location-closed, fulfilment-required,
outside-delivery-zone, network, and API failures.
Validation failures also expose a stable `error.reasonCode` such as
`CART_EMPTY`, `DELIVERY_ADDRESS_REQUIRED`, `INVALID_SCHEDULE_SLOT`,
`ORDERING_UNAVAILABLE`, or `CUSTOMER_PHONE_REQUIRED`, so hosts can select UI
without parsing messages.

For a compact functional trace, pass `onTelemetry` to `createOrderSdk`. In
addition to checkout lifecycle events, it receives redacted `sdk_operation`
events for `validateOrder`, `placeOrder`, and `chargePayment`; only the
operation, status, and optional reason code are included.

```ts
const order = createOrderSdk({
  businessId: "business-id",
  onTelemetry: (event) => {
    if (event.name === "sdk_operation") {
      console.log(event.operation, event.status, event.reasonCode);
    }
  },
});
```

## Validation order

The SDK validates locally before any operation that can call the ordering API:

1. `setFulfilment` checks the order type, location, delivery area/coordinates,
   and schedule shape. When bootstrap includes storefront metadata, it also
   rejects disabled branches, unsupported order types, and invalid delivery
   zones locally. A rejected context does not update the cart.
2. `addItem` checks quantity and modifier groups, then requires the validated
   fulfilment before sending the cart request.
3. `validateOrder` normalizes the cart, fulfilment, customer, and payment data
   without placing an order.
4. `placeOrder` runs the same validation and flushes pending cart mutations,
   then sends the normalized payload. The API can still reject stale,
   unavailable, or server-side business rules; those responses are returned as
   SDK errors.

This gives hosts immediate, generic requirements for UI recovery while keeping
the API as the final authority.

## Built-in HTTP API contract

When `businessId` is supplied, the built-in transport calls the canonical
Ordrz v1 base (`https://apiv2.ordrz.com/api/v1`) by default. If a host supplies
an API origin instead, the SDK adds `/api/v1`; if it supplies the v1 base, the
SDK adds `/public`:

| Operation | Request |
| --- | --- |
| Load cart | `GET /public/cart` with `X-Cart-Id` |
| Add item | `POST /public/cart/items` |
| Update line | `PATCH /public/cart/items/:lineId` |
| Remove line | `DELETE /public/cart/items/:lineId` |
| Clear cart | `DELETE /public/cart` |
| Calculate totals | `POST /public/cart/calculate` |
| Place order | `POST /public/orders` |
| Charge online payment | `POST /public/orders/:id/charge` |
| Customer login OTP | `POST /public/customers/login` |
| Customer signup OTP | `POST /public/customers/signup` |
| Verify customer OTP | `POST /public/customers/verify-otp` |
| Saved addresses | `GET/PATCH /public/customers/addresses` |
| Customer order history | `GET /public/customers/orders` |
| Business customer profile/orders | `GET /business/:businessId/customers/:customerId/orders` |
| Storefront discovery | `GET /public/storefront/username/:username` or `/public/storefront/domain/:domain` |
| Storefront locations | `GET /public/locations/business/:businessId` |
| Storefront products | `GET /business/:businessId/products` |

Use `apiPathPrefix: "/api"` when a host exposes a compatibility BFF at
`/api/cart` and `/api/orders` (as XO does locally). The documented public API
prefix is the default.

Successful responses should use `{ success: true, data: ... }`. A create-or-add
response should return the new cart ID in `X-Cart-Id`. If a provider has a
different API, implement `CartApiAdapter` and `OrderApiAdapter`; the host still
uses the same SDK methods and does not reimplement cart logic.

## Theme, header, and footer

Pass the host's public theme through `CheckoutRuntimeConfig.theme` and the
profile theme through `OrderSDKProfileConfig.theme`. Each MFE applies scoped
theme variables. Set `hostShell: true` (the default) so the host's existing
header/footer remain outside the MFE; the SDK does not copy or replace the host
shell. When Checkout and Profile are mounted from the same `createOrderSdk`
instance, the SDK owns their shared customer session and authentication bridge;
the host does not need a second sign-in or profile client.

## Script-tag usage

For a browser-only host, build and publish the loader artifact and configure a
pinned MFE URL before loading it:

```html
<div id="checkout-root"></div>
<script>
  window.__TOSSDOWN_CHECKOUT_MFE_URL__ =
    "https://checkout-cdn.example/v1/index.global.js";
</script>
<script src="https://cdn.example/order-sdk/v1/loader.global.js"
        crossorigin="anonymous"></script>
```

The script-tag loader exposes the lower-level `window.TossdownCheckoutSDK` API.
For complete cart + checkout orchestration, prefer the npm import and
`createOrderSdk`, or publish a site-owned wrapper that calls it.

## Lifecycle and security

- Call `order.destroy()` when the host route/component is disposed.
- Keep cart IDs opaque and use HTTPS in production.
- Never pass card data, payment secrets, or private provider credentials.
- Only pass browser-safe map keys and public payment configuration.
- Treat `cartSnapshot` as a rendering hint; server cart data remains authoritative.
- Pin the MFE URL and apply CSP/SRI at deployment.
- Run `npm run typecheck`, `npm test`, and `npm run build` before publishing.

## Lower-level checkout-only API

`createCheckoutSdk` remains available for compatibility when a host already has
its own cart/order engine. New hosts that want the SDK to handle cart and
checkout should use `createOrderSdk` instead.

```ts
import { createCheckoutSdk } from "@tossdown/orders-sdk";

const checkout = createCheckoutSdk({
  mfeUrl: "https://checkout-cdn.example/v1/index.global.js",
});

const instance = await checkout.mount("#checkout-root", runtimeConfig, hooks);
instance.unmount();
```
